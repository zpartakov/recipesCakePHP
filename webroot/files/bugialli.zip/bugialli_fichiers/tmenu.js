// T-Menu 1.1 (c) 2002 by Charles Foster
//
// T-Menu is a DHTML Menu system written for any browser
// that supports W3C standards. [www.w3.org]
//
// [Mozilla, NS 6/7, Opera 5/6/7, IE 5/6+, Konqueror 2/3]
//
// ######## v1.1 - Nov 17 2002 ########
// # Now supports infinity MenuBars instead of just 1 (Stuuuupid boy!)
// # setArrowImagesPath(String) & loadArrowImages() added to MenuBar
// # Fixed a small arrow image loading bug
//
// Feel free to use the T-Menu for non-commercial purposes.
// If you intend to use T-Menu for commercial purposes, please
// contact me with an e-mail
//
// 13/04/03 - Fixed multiple MenuBar bug
//
// http://www.cfoster.net/tmenu/

var ua		= navigator.userAgent;
var opera	= /opera [56789]|opera\/[56789]/i.test(ua);
var ie		= !opera && /msie [56789]/i.test(ua);
var ieBox = ie && (document.compatMode == null || document.compatMode != "CSS1Compat");
var moz		= !opera && /mozilla\/[56789]/i.test(ua);
var kon   = /Konqueror/i.test(ua);
var lin   = /Linux/i.test(ua);

// JS Constants
var TMENU_IMAGES_PATH  = "images/"; // left in for v1.0 data files
var MENU_HOVER_MODE    = opera || kon ? true:false;
var ITEM_BORDER_SIZE   = 1;
var ITEM_MARGIN_SIZE   = 1;
var DEFAULT_ICON_SIZE  = opera ? 18:20;
var DEFAULT_MENU_WIDTH = 128;
var MENU_HIDE_TIMEOUT  = opera ? 1:10;

var _arrowD = null;
var _arrowR = null; // loaded later

// -

amt = (opera) ? 4:(moz && lin) ? -8:(moz) ? -11:(ie) ? -11:(kon) ? 14:0;
amr = (opera) ? 3:(moz) ? 3:(ie) ? 4:(kon) ? 2:0;
amCSS = amt+"px "+amr+"px 0px 0px";

imt = (ie || moz) ? 1:0;
imr = (ie) ? 3:0;
iml = (ie || moz) ? 2:0;
imCSS = imt+"px "+imr+"px 0px "+iml+"px";

var MenuHandler = {
	all : [],
	// since 1.1:
	pid : "T-Menu-",
	mbcntr : 0,
	item_prefix : "item-",
	frame_prefix : "box-",
	// ---
	_over : function(o) {
		Tthread.stop();
	},
	_out : function(o) {
		Tthread.stop();
		Tthread.start();
	},
	_blur : function(o) {
		window.menutimeout = setTimeout("MenuHandler.hideAllSubs();",350);
	},
	show_frame : function(id) {
		document.getElementById(id).style.visibility = "visible";
	},
	show_sub : function(id,y) {
		this.show_submenu(id,
		y.offsetParent.offsetLeft+y.offsetWidth + (ITEM_MARGIN_SIZE*2 + ITEM_BORDER_SIZE),
		y.offsetParent.offsetTop+y.offsetTop);
	},
	show_submenu : function(id,x,y)
	{
		_bh = layout.getBrowserHeight()+layout.getScrollY();
		_bw = layout.getBrowserWidth()+layout.getScrollX();
		_wi = document.getElementById(id).offsetWidth;
		_hi = document.getElementById(id).offsetHeight;
		document.getElementById(id).style.left = ((x + _wi > _bw) ? ((x-(_wi*2)+10 > 0) ? x-(_wi*2)+10:0):x) + "px";
		document.getElementById(id).style.top = ((_hi > _bh) ? 0:(y + _hi > _bh) ? _bh-_hi:y) + "px";
		this.show_frame(id);
	},
	hide_frame : function(id) {
		document.getElementById(id).style.visibility = "hidden";
	},
	changeIcon : function(obj,src) {
		document.getElementById(obj.id+"-image").src = src;
	},
	hideAllSubs : function() {
		for(this.i=0;this.i<this.all.length;this.i++) {
			document.getElementById(this.all[this.i]).style.visibility = "hidden";
		}
	},
	sortIDs : function(obj,prefix) {
		for(this.i=0;this.i<obj.items.length;this.i++)
		{
			obj.items[this.i].id = prefix+"-"+this.i;
		}
		for(this.x=0;this.x<obj.submenus.length;this.x++)
		{
			obj.submenus[this.x].action.id = MenuHandler.frame_prefix+obj.submenus[this.x].id;
			MenuHandler.all[MenuHandler.all.length] = obj.submenus[this.x].action.id;
			new MenuHandler.sortIDs(obj.submenus[this.x].action,obj.submenus[this.x].id);
		}
	}
};
var layout = {
	getTop : function(el) {
		this.value = el.offsetTop;
		if(el.offsetParent)
		{
			this.value += layout.getTop(el.offsetParent);
		}
		return this.value;
	},
	getLeft : function(el) {
		this.value = 0;
		if(el.offsetParent)
		{
			this.value += layout.getLeft(el.offsetParent);
			return this.value + el.offsetParent.offsetLeft;
		}
		return 0;
	},
	getHeight : function(el) {
		return (moz) ? el.offsetHeight:el.offsetHeight;
	},
	getBrowserWidth : function() { return ie ? (ieBox ? document.body.clientWidth:document.documentElement.clientWidth):window.innerWidth; },
	getBrowserHeight : function() { return ie ? (ieBox ? document.body.clientHeight:document.documentElement.clientHeight):window.innerHeight; },
	getScrollY : function() { return ie ? (ieBox ? document.body.scrollTop:document.documentElement.scrollTop):window.pageYOffset; },
	getScrollX : function() { return ie ? (ieBox ? document.body.scrollLeft:document.documentElement.scrollLeft):window.pageXOffset; },
	getX : function(obj) {
		return obj.offsetLeft + layout.getLeft(obj);
	},
	getY : function(obj) {
		if(kon) { return layout.getTop(obj) + obj.offsetHeight; }
		return layout.getTop(obj) + layout.getHeight(obj);
	}
};
var Tthread = {
	_tmr : 0,
	_tt : MENU_HIDE_TIMEOUT*10,
	start : function() {
		this._tmr++;
		window.menutimeout = setTimeout("Tthread.start()",100);
		if(this._tmr >= this._tt) {
			MenuHandler.hideAllSubs();
			this.stop();
		}
	},
	stop : function() {
		if(window.menutimeout != null) { window.clearTimeout(window.menutimeout); }
		this.reset();
	},
	reset : function() { this._tmr = 0; }
};
function Menu(M,t)
{
	this.image = false;
	this.label = false;
	if(M)
	{
		if(M.isImage) { this.image = M; }
		else { this.label = M; }
	}
	this.width = DEFAULT_MENU_WIDTH;
	this.id = "";
	this.items = [];
	this.submenus = [];
	this.tooltip = (t!=null) ? t:false;
	this.isMenu = true;
	this.href = null;
}
Menu.prototype.toString = function() {
	this.s = "<div id='"+this.id+"' class='T-Menu' style='width:"+this.width+"px;'>";
	for(i=0;i<this.items.length;i++)
	{
		if(this.items[i].isSeparator)
		{
			this.s += "<div id='"+this.items[i].id+"' class='T-Menu-separator'></div>";
		}
		else
		{
			loc = (this.items[i].isSub) ? "javascript:void(0);":this.items[i].action;
			this.s += "<a id='"+this.items[i].id+"' "+
								"href='"+loc+"' "+
								"unselectable='on' tabindex='-1' "+
								((this.items[i].tooltip) ? "title='"+this.items[i].tooltip+"' ":"")+
								"onMouseOver='"+this.getSubMenuCode()+
								(this.items[i].isSub ? "MenuHandler.show_sub(\""+this.items[i].action.id+"\",this);":"")+
								((this.items[i].iconImage) ? "MenuHandler.changeIcon(this,\""+this.items[i].iconImage.over_object.src+"\");":"")+
								"MenuHandler._over(this);' "+
								"onMouseOut='MenuHandler._out(this);"+
								((this.items[i].iconImage) ? "MenuHandler.changeIcon(this,\""+this.items[i].iconImage.object.src+"\");":"")+
								"' "+
								((this.items[i].iconImage) ? "onMouseUp='MenuHandler.changeIcon(this,\""+this.items[i].iconImage.object.src+"\");'":"")+
								((opera || this.items[i].iconImage) ?
								"onMouseDown='"+
								((opera) ? "window.location.href=\""+loc+"\";":"")+
								((this.items[i].iconImage) ? "MenuHandler.changeIcon(this,\""+this.items[i].iconImage.clicked_object.src+"\");":"")+
								"' ":"")+
								" class='T-Menu-mi'"+((!this.items[i].iconImage) ? " style='padding-left:"+DEFAULT_ICON_SIZE+"px;'":"")+">"+
								((this.items[i].iconImage) ? "<img id='"+this.items[i].id+"-image' src='"+this.items[i].iconImage.object.src+"' class='T-Menu-icon' style='margin:"+imCSS+";' alt=''>":"")+
								this.items[i].label+
								(this.items[i].isSub ? "<img src='"+_arrowR.object.src+"' class='T-Menu-arrow' style='margin:"+amCSS+";' alt=''>":"")+
								"</a>";
		}
	}
	this.s += "</div>";
	for(this.i=0;this.i<this.submenus.length;this.i++) { this.s += this.submenus[this.i].action; }
	return this.s;
};
Menu.prototype.getSubMenuCode = function() {
	this.str = "";
	for(this.i=0;this.i<this.submenus.length;this.i++)
	{
		this.str += "MenuHandler.hide_frame(\""+this.submenus[this.i].action.id+"\");";
		this.str += this.submenus[this.i].action.getSubMenuCode();
	}
	return this.str;
};
Menu.prototype.add = function(obj) {
	if(obj.isSub) { this.submenus[this.submenus.length] = obj; }
	this.items[this.items.length] = obj;
};
Menu.prototype.addSeparator = function() {
	tmp = new MenuItem("","","");
	tmp.isSeparator = true;
	this.items[this.items.length] = tmp;
};
function MenuItem(l,a,t)
{
	this.id = "";
	this.label = l;
	this.isSeparator = false;
	this.action = a;
	this.tooltip = (t == null) ? false:t;
	this.isSub = (a.isMenu) ? true:false;
	this.iconImage = false;
}
MenuItem.prototype.setIconImage = function(i) { this.iconImage = i; };
function MenuBar()
{
	this.id = MenuHandler.pid+(MenuHandler.mbcntr++); // since 1.1
	this.x = 0;
	this.y = 0;
	this.isAbsolute = false;
	this.obj = [];
	this.img_path = TMENU_IMAGES_PATH;
	this.img_loaded = false;
}
MenuBar.prototype.setArrowImagesPath = function(p) { this.img_path=p; };
MenuBar.prototype.loadArrowImages = function() {
	_arrowD = new image(this.img_path+"d_arrow.gif",7,4);
	_arrowR = new image(this.img_path+"arrow.gif",4,7);
	this.img_loaded=true;
};
MenuBar.prototype.add = function(obj) { this.obj[this.obj.length] = obj; };
MenuBar.prototype.toString = function() {
	window.status = "Generating T-Menu";
	if(!this.img_loaded)
		this.loadArrowImages();

	for(this.L=0;this.L<this.obj.length;this.L++)
	{
		MenuHandler.sortIDs(this.obj[this.L],MenuHandler.item_prefix+this.L);
		this.obj[this.L].id = MenuHandler.pid+(MenuHandler.mbcntr-1)+"-"+MenuHandler.frame_prefix+MenuHandler.item_prefix+this.L;
		MenuHandler.all[MenuHandler.all.length] = this.obj[this.L].id;
		MenuHandler.mbcntr++; // 13/04/03
	}
	konProps = (kon) ? "float:left;":"";
	display = (this.isAbsolute) ? "position:absolute;left:"+this.x+"px;top:"+this.y+"px;":"";

	ret = "<span id='"+this.id+"' class='T-MenuBar' "+((this.isAbsolute) ? " style='margin:0px;padding:0px;"+display+"'":"")+">"; // 1.1
	for(i=0;i<this.obj.length;i++)
	{
		_k = (kon && this.isAbsolute) ? 10:0;
		_pos = (this.obj[i].isMenu) ? "MenuHandler.show_submenu('"+this.obj[i].id+"',"+
		"layout.getX(this)-"+_k+",layout.getY(this)-"+_k+");":"";

		_tt = this.obj[i].tooltip ? this.obj[i].tooltip:"";
		_sub = "MenuHandler.hideAllSubs();Tthread.stop();Tthread.start();"+_pos;
		_act = (this.obj[i].isMenu) ? "javascript:void(0);":this.obj[i].href;
		hov = MENU_HOVER_MODE ? "onMouseOver=\""+((opera || kon) ? _sub:"this.focus();")+"\" ":"";
		_bt = (this.obj[i].image) ? "<img border='0' alt='"+_tt+"' src='"+this.obj[i].image.object.src+"' "+
		"onMouseOver=\"this.src='"+this.obj[i].image.over_object.src+"';"+((kon && MENU_HOVER_MODE) ? _sub:"")+"\" "+
		"onMouseOut=\"this.src='"+this.obj[i].image.object.src+"';\" "+
		"onMouseDown=\"this.src='"+this.obj[i].image.clicked_object.src+"';\" "+
		"onMouseUp=\"this.src='"+this.obj[i].image.object.src+"';\" "+
		(this.obj[i].image.w ? "width='"+this.obj[i].image.w+"' ":"")+(this.obj[i].image.h ? "height='"+this.obj[i].image.h+"' ":"")+
		((this.obj[i].isMenu && kon) ? "onclick=\""+_sub+"\" ":"onclick='window.location.href=\""+_act+"\";' ")+
		">":this.obj[i].label;
		_da = (!this.obj[i].image && this.obj[i].isMenu) ? "<img class='down_arrow' src='"+_arrowD.object.src+"' alt=''>":"";

		// onclickk -> _bt used & onfocus of <A> 4 same thing

		ret += "<a "+((!kon) ? hov:"")+"onfocus=\""+_sub+"\" onblur='MenuHandler._blur(this);' href='"+_act+"'"+((_tt) ? " title='"+_tt+"'":"")+((!this.obj[i].image) ? " class='TButton'":"")+">";
		ret += _bt+_da;
		ret += "</a>";
	}
	ret += "</span>";
	for(this.I=0;this.I<this.obj.length;this.I++) { ret += this.obj[this.I]; }
	window.status = "";
	return ret;
};
function MenuButton(l,h,t)
{
	this.t = new Menu(l);
	this.t.isMenu=false;
	this.t.href=h;
	this.t.tooltip=t;
	return this.t;
}
function image(loc,w,h)
{
	this.w = w!=null ? w:false;
	this.h = h!=null ? h:false;
	this.object = new Image();
	this.over_object = new Image();
	this.clicked_object = new Image();
	this.object.src = this.over_object.src = this.clicked_object.src = loc;
	this.isImage = true;
}
image.prototype.setImage = function(loc) { this.object.src = loc; };
image.prototype.setOverImage = function(loc) { this.over_object.src = loc; };
image.prototype.setClickedImage = function(loc) { this.clicked_object.src = loc; };